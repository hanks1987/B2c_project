live800_companyID="56122";
var enterurl="http://www.thinkshop.cn/brandshop.php";
jid="4998953177";
live800_configID="37884";
var live800_baseUrl="chat.live800.com";
var live800_baseHtmlUrl="chat.live800.com";
var live800_baseWebApp="/live800";
var live800_baseChatHtmlDir="/chatClient";
live800_status="1";
live800_Language="zh";
live800_configContent="live800_invite_auto=0&live800_invite_delay=3&live800_invite_style=0&live800_invite_top=0&live800_invite_title=%E9%82%80%E8%AF%B7";
live800_inviteContent="%E6%AC%A2%E8%BF%8E%E5%85%89%E9%A1%BE%E5%95%86%E5%9F%8E%E5%95%86%E5%9F%8E%2C%E6%9C%89%E4%BB%80%E4%B9%88%E5%8F%AF%E4%BB%A5%E5%B8%AE%E5%8A%A9%E6%82%A8%E7%9A%84%E5%90%97%3F";
live800_visitorAddr="%E6%AC%A2%E8%BF%8E%E6%82%A8%EF%BC%8C%E6%9D%A5%E8%87%AA%E5%8C%97%E4%BA%AC%E5%B8%82%E7%9A%84%E6%9C%8B%E5%8F%8B";

document.write("<scr"+"ipt language=\"javascript\" src=\"http://chat.live800.com/live800/chatClient/monitorStatic.js\"></scr"+"ipt>");