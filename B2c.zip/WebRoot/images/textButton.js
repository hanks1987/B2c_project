live800_companyID="56122";
var enterurl="http://www.thinkshop.cn/brandshop.php";
jid="4998953177";
live800_configID="37885";
var live800_baseUrl="chat.live800.com";
var live800_baseHtmlUrl="chat.live800.com";
var live800_baseWebApp="/live800";
var live800_baseChatHtmlDir="/chatClient";
live800_codeType="steady";
live800_configContent="live800_text=%25u5728%25u7EBF%25u5BA2%25u670D&live800_switch=0";

document.write("<scr"+"ipt language=\"javascript\" src=\"http://chat.live800.com/live800/chatClient/textStatic.js\"></scr"+"ipt>");