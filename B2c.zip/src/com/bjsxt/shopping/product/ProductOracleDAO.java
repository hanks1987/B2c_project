package com.bjsxt.shopping.product;

import java.util.List;

public class ProductOracleDAO implements ProductDAO {

	public void add(Product p) {
		// TODO Auto-generated method stub

	}

	public void delete(int id) {
		// TODO Auto-generated method stub

	}

	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getProducts(List<Product> products, int pageNo, int pageSize, boolean lazy) {
		// TODO Auto-generated method stub
		return -1;
	}

	public Product loadById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(Product p) {
		// TODO Auto-generated method stub

	}

	public void delete(String conditionStr) {
		// TODO Auto-generated method stub
		
	}

	public int find(List<Product> products, int pageNo, int pageSize, String queryStr) {
		// TODO Auto-generated method stub
		return 0;
	}

}
