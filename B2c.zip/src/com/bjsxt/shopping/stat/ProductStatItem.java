package com.bjsxt.shopping.stat;

public class ProductStatItem {
	private int productId;

	private String productName;

	private int totalSalesCount;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getTotalSalesCount() {
		return totalSalesCount;
	}

	public void setTotalSalesCount(int totalSalesCount) {
		this.totalSalesCount = totalSalesCount;
	}

}
